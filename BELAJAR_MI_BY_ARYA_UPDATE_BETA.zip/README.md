# Belajar MI by.arya

Prototype PWA mobile-friendly dengan tema biru gelap, dapat dibungkus menjadi APK Android menggunakan Capacitor.

## Fitur
- Belajar bahasa Inggris: kosakata dan kuis.
- Kalkulator ilmiah dasar.
- Konversi panjang, suhu, dan kalkulator persentase.
- **Akademi Coding:** pengenalan HTML, CSS, JavaScript, dan urutan belajar.
- **Akademi Manajemen Informatika:** penjelasan bidang studi, materi utama, contoh penerapan, kemampuan, dan bidang pekerjaan terkait.
- **Sistem Ujian:** 10 soal pilihan ganda, penilaian otomatis, pembahasan, pengulangan, nilai terbaik, dan riwayat nilai per akun.
- **Akun mahasiswa offline:** pendaftaran mandiri atau dibuat admin; login, logout, nama tampilan, dan username.
- **Panel admin:** membuat akun mahasiswa, melihat daftar akun dan riwayat nilai, mengatur ulang password mahasiswa, mengganti password admin, menghapus akun, serta mengekspor cadangan data JSON.
- Service Worker untuk cache offline dan manifest PWA.

## Akun awal admin
- Username: `admin`
- Password awal: `miadmin123`
- Setelah login pertama, buka Panel Admin lalu pilih **Ganti password admin**.

Mahasiswa dapat mendaftar dari layar login atau dibuatkan akunnya oleh admin. Login lama melalui tombol **Akses lama (SAWIT)** tetap tersedia untuk menjaga akses dari versi sebelumnya.

## Penyimpanan offline
Akun dan nilai disimpan menggunakan `localStorage` pada perangkat/browser yang menjalankan aplikasi. Data tidak tersinkron antarperangkat dan dapat hilang jika data aplikasi/browser dihapus atau aplikasi di-uninstall. Admin dapat mengekspor JSON sebagai cadangan. Untuk memindahkan data, mekanisme impor perlu ditambahkan.

Versi ini adalah prototipe offline satu perangkat, bukan sistem autentikasi server. Data akun disimpan lokal sehingga tidak cocok untuk menyimpan informasi sensitif atau digunakan sebagai sistem akademik resmi dengan kebutuhan keamanan tinggi.

## Menjalankan
Buka `index.html` di browser untuk preview. Untuk instalasi PWA, host folder ini pada HTTPS lalu buka dari Chrome Android dan pilih **Install app / Tambahkan ke layar utama**.

## Build APK melalui GitHub
1. Buat repository GitHub (Private disarankan).
2. Ekstrak ZIP dan upload seluruh isi folder ke root repository.
3. Buka tab **Actions** dan aktifkan GitHub Actions jika diminta.
4. Pilih workflow **Build BELAJAR MI Android APK**, lalu tekan **Run workflow**. Workflow juga berjalan otomatis saat ada push ke branch `main`.
5. Setelah workflow selesai, unduh artifact `BELAJAR-MI-by-Arya-debug-APK`.
6. Ekstrak artifact dan instal `app-debug.apk` di Android.

Hasil workflow adalah APK debug untuk pengujian dan instalasi pribadi, bukan APK release bertanda tangan untuk Play Store. Build pertama membutuhkan internet.


## Pemberitahuan versi
Aplikasi menampilkan pemberitahuan: **VERSI INI MASIH BETA SILAHKAN TUNGGU ADMIN MBG UPDATE by. arya** pada layar masuk dan beranda.
