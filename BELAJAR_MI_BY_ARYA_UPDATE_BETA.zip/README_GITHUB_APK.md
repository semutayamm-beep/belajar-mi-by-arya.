# BELAJAR MI by Arya — GitHub APK starter

Project ini membungkus PWA Belajar MI menjadi APK Android menggunakan Capacitor dan GitHub Actions. Fitur akun offline, panel admin, akademi, dan ujian sudah termasuk dalam sumber `index.html`.

## Build APK melalui GitHub dari HP
1. Buat repository GitHub baru (Private disarankan).
2. Ekstrak ZIP ini, lalu upload seluruh isi folder ke root repository. Pastikan `index.html`, `assets/`, `package.json`, `capacitor.config.json`, dan `.github/workflows/build-apk.yml` ikut ter-upload.
3. Buka tab **Actions** pada repository. Jika diminta, aktifkan GitHub Actions.
4. Pilih workflow **Build BELAJAR MI Android APK**, lalu tekan **Run workflow**. Workflow juga berjalan otomatis saat ada push ke branch `main`.
5. Setelah selesai, buka proses workflow yang hijau, gulir ke bagian **Artifacts**, lalu unduh `BELAJAR-MI-by-Arya-debug-APK`.
6. Ekstrak artifact dan instal `app-debug.apk` di Android.

## Akun awal
- Admin: `admin`
- Password awal: `miadmin123`
- Ganti password admin dari Panel Admin setelah login.
- Mahasiswa dapat mendaftar sendiri atau dibuatkan akun oleh admin.

## Catatan
- APK yang dihasilkan adalah APK debug, bukan APK release Play Store.
- Akun dan nilai tersimpan offline pada perangkat masing-masing. Tidak ada sinkronisasi antar-HP.
- Data lokal bukan autentikasi server dan tidak cocok untuk data sensitif.
- Nama paket Android: `com.arya.belajarmi`.
- Build pertama membutuhkan internet dan mungkin memerlukan beberapa menit.
